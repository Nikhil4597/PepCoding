#!/usr/bin/env bash
[ -f "$HOME/.vim/ftdetect/feder.vim" ] && cp "$HOME/.vim/ftdetect/feder.vim" feder_ftdetect.vim
[ -f "$HOME/.vim/syntax/feder.vim" ] && cp "$HOME/.vim/syntax/feder.vim" feder_syntax.vim
